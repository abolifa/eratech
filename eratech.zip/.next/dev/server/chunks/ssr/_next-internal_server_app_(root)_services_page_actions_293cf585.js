module.exports = [
"[project]/.next-internal/server/app/(root)/services/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28root%29_services_page_actions_293cf585.js.map