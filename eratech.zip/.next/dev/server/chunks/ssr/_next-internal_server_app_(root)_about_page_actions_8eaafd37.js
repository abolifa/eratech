module.exports = [
"[project]/.next-internal/server/app/(root)/about/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28root%29_about_page_actions_8eaafd37.js.map