(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_52e129f4._.js",
  "static/chunks/app_(root)_page_tsx_46106ceb._.js"
],
    source: "dynamic"
});
