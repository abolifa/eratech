module.exports=[69377,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28root%29_about_page_actions_8eaafd37.js.map