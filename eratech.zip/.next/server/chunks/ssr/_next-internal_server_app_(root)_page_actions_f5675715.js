module.exports=[37930,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28root%29_page_actions_f5675715.js.map