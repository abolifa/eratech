module.exports=[77444,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28root%29_projects_page_actions_257a5532.js.map