module.exports=[87896,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28root%29_services_page_actions_293cf585.js.map