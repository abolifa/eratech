var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact/route.js")
R.c("server/chunks/[root-of-the-server]__1b8b210d._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__644eff22._.js")
R.c("server/chunks/_next-internal_server_app_api_contact_route_actions_0bce5875.js")
R.m(10044)
module.exports=R.m(10044).exports
